//
//public class GorillaTest {
//	public static void main(String[] args) {
//		
//		Gorilla gorillaBot = new Gorilla();
//
//		//test 3 throws
//		gorillaBot.throwSomething();
//		gorillaBot.throwSomething();
//		gorillaBot.throwSomething();
//		// eat 2 bananas
//		gorillaBot.eatBananas();
//		gorillaBot.eatBananas();
//		// climb something 1 time
//		gorillaBot.climb();
//		
//
//	}
//}
