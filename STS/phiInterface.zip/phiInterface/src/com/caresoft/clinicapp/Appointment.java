package com.caresoft.clinicapp;

//.. lots of existing imports .. //
public class Appointment {
 // ... you see lots of code here, and you can leave as is for the assignment... // 
}