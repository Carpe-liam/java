package com.caresoft.clinicapp;

public class User{

    protected Integer id;
    protected int pin;
    
// TO DO: Getters and setters
    public Integer getId() {
    	return id;
    }
    public void setId(Integer id) {
    	this.id = id;
    }
    public int getPin() {
    	return pin;
    }
    public void setPin(int pin) {
    	this.pin = pin;
    }
    

    
// ... you see lots of code here, and you can leave as is. Just add getters and setters)... //

}
