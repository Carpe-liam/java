package com.alex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruityLoopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
